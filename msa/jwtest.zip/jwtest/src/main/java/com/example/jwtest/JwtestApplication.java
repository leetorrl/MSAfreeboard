package com.example.jwtest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtestApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtestApplication.class, args);
	}

}
