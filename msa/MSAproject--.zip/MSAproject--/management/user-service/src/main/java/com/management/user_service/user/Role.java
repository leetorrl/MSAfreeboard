package com.management.user_service.user;

public enum Role {
    ROLE_STUDENT,
    ROLE_TEACHER,
    ROLE_MANAGER,
    ROLE_ADMIN
}